#include<iostream>
#include<vector>
using namespace std;

void getSets(long long, long long, long long, long long [], int);

int maxVal=0;
int N;

int main(){
    long long maxSum, n,k;
    cout<<"Enter max sum and size of resulting set and index\n";
    cin>>maxSum>>N>>k;
    long long arr[N];
    getSets(maxSum,0, N, arr,k);
    cout<<"max kth value is "<<maxVal;
    return 0;
}

void getSets(long long cs, long long res , long long n, long long a[],int k){
    //cout<<"\n cs"<<cs<<" n "<<n<<endl;
    if(cs == 0){
        cout<<res<<endl;
        cout<<endl;
        if(a[k]>maxVal){
            maxVal = a[k];
        }
        return;
    }
    if(n == 0){
        return;
    }
    for(int i=1; i<=(cs-(n-1)); i++){
        if(N-n == 0){
            a[0] = i;
            getSets(cs-i, res*10+i, n-1, a,k);
        }
        else{
            if(abs(a[N-n-1] - i)<=1){
                a[N-n] = i;
            getSets(cs-i, res*10+i, n-1, a,k);
            }
        }
    }
}
