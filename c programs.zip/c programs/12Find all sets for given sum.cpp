#include<iostream>
#include<vector>
using namespace std;

void get(int,int);

int main(){
    cout<<"enter no";
    int no;
    cin>>no;

    get(no,0);
    return 0;
}
void get(int cs, int r){
    //cout<<"current sum "<<cs<<endl;
    if(cs == 0){

        cout<<r<<endl;

        return;
    }
    if(cs < 0){
        return;
    }
    else{
        for(int i =1; i<= cs; i++){

                get(cs-i,r*10+i);


        }
    }
}
